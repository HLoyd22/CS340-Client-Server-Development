from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:37176/AAC' % (username, password))
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        try:
            if data is not None:
                insert_result = self.database.animals.insert_one(data) #data should be dictionary
                print(insert_result)
                return True
            else:
                #Raise error
                raise Exception("Nothing to save, data is empty")
        except:
            return False # return false for bool requirement

# Create method to implement the R in CRUD.
    def read(self, data):
        try:
            if data is not None:
                read_result = list(self.database.animals.find(data, {"_id": False}))
                return read_result
            else:
                raise Exception("Nothing to find. Target is empty.")
                return False
        except Exception as e:
            print("Exception has occured: ", e)
        
# Create method to implement the U in CRUD.
    def update(self, keyValue, updateValue):
        if updateValue is not None:  
            self.database.animals.update(keyValue, updateValue) # data should be dictionary
            return True
        else:
            print('Failed. Data parameter is empty, nothing to save.')
            return False

# Create method to implement the D in CRUD.
    def delete(self, keyValue):
        if keyValue is not None:
            self.database.animals.remove(keyValue) # data shoud be dictonary
            return True
        else:
            print('Failed. Data parameter is empty, nothing to delete.')
            return False
        
